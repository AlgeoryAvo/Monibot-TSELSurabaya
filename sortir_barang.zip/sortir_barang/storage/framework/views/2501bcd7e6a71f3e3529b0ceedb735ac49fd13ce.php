<div>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-table comman-shadow">
                        <div class="card-body">
                            <div class="page-header">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <h3 class="page-title">Edit Produk</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <form wire:submit.prevent='update(<?php echo e($idx); ?>)' method="post">
                                    <?php echo csrf_field(); ?>
                                    <table class="table">
                                        <tr>
                                            <td>Produk</td>
                                            <td>
                                                <input type="text" required class="form-control" wire:model='product'
                                                    placeholder="Masukan Produk">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Terjual</td>
                                            <td>
                                                <input type="number" required class="form-control" wire:model='terjual'
                                                    placeholder="Masukan Terjual">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Harga</td>
                                            <td>
                                                <input type="number" required class="form-control"
                                                    wire:model='price' placeholder="Masukan harga">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td>
                                                <a href="<?php echo e(route('product')); ?>" class="btn btn-warning"><i
                                                        class="fas fa-sync-alt    "></i> Kembali</a>
                                                <button type="submit" class="btn btn-primary ">
                                                    <div wire:loading wire:target="update" wire:key="update"><i
                                                            class="fa fa-spinner fa-spin"></i></div> Simpan
                                                </button>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="content-backdrop fade"></div>
    </div>
    <?php if(session()->has('insert')): ?>
        <script>
            Swal.fire(
                "Informasi",
                "<?php echo e(session('insert')); ?>",
                "success"
            );
        </script>
    <?php endif; ?>

</div>
<?php /**PATH C:\laravel\sortir_barang\resources\views/livewire/backend/product/editproduct.blade.php ENDPATH**/ ?>