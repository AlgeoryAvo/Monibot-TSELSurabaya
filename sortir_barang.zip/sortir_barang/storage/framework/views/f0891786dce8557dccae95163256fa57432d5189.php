<div>
    <div class="content-wrapper">
        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-table comman-shadow">
                        <div class="card-body">
                            <div class="page-header">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <h3 class="page-title">Form Edit Operator</h3>
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <form wire:submit.prevent='update(<?php echo e($idX); ?>)' method="post">
                                    <?php echo csrf_field(); ?>
                                    <table class="table">
                                        <tr>
                                            <td>Nama</td>
                                            <td>
                                                <input type="text"  class="form-control" wire:model='name'
                                                    placeholder="Masukan Nama">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Email</td>
                                            <td>
                                                <input type="email"  class="form-control" wire:model='email'
                                                    placeholder="Masukan Email">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Password</td>
                                            <td>
                                                <input type="password"  class="form-control"
                                                    wire:model='password' placeholder="Masukan password">
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Level</td>
                                            <td>
                                                <select wire:model='level' class="form-control">
                                                    <option value="">Pilih</option>
                                                    <option value="Sales">Sales</option>
                                                    <option value="Operator">Operator</option>
                                                    <option value="Atasan">Atasan</option>
                                                </select>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td></td>
                                            <td>
                                                <a href="<?php echo e(route('operator')); ?>" class="btn btn-warning"><i
                                                        class="fas fa-sync-alt    "></i> Kembali</a>
                                                <button type="submit" class="btn btn-primary ">
                                                    <div wire:loading wire:target="update" wire:key="update"><i
                                                            class="fa fa-spinner fa-spin"></i></div> Simpan
                                                </button>
                                            </td>
                                        </tr>
                                    </table>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <div class="content-backdrop fade"></div>
    </div>

    <?php if(session()->has('insert')): ?>
        <script>
            Swal.fire(
                "Informasi",
                "<?php echo e(session('insert')); ?>",
                "success"
            );
        </script>
    <?php endif; ?>

</div>
<?php /**PATH C:\laravel\sortir_barang\resources\views/livewire/backend/user/edituser.blade.php ENDPATH**/ ?>