<div>
    <div class="content-wrapper">
        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="card">
                <div class="card-header">
                    Data Operator
                </div>
                <div class="card-body table-responsive">
                    <a href="<?php echo e(route('form-operator')); ?>" class="btn btn-primary">Tambah Data Operator</a>
                    <div class="col-auto text-end float-end ms-auto download-grp">
                        <input type="text" wire:model="search" class="form-control" autocomplete="off"
                            placeholder="Cari data">
                    </div>
                    <br>
                    <br>
                    <table class="table  table-hover table-bordered" id="">
                        <thead class="student-thread">
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Email</th>
                                <th>Level</th>
                                <th class="">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0; ?>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $no++; ?>
                                <tr>
                                    <td>
                                        <?php echo $no; ?>
                                    </td>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->email); ?></td>
                                    <td><?php echo e($row->level); ?></td>
                                    <td>
                                        <a wire:click="$emit('triggerDelete',<?php echo e($row->id); ?>)"
                                            class="btn btn-danger btn-sm">
                                            <i class="fa fa-trash text-light"></i>
                                        </a>
                                        <a href="<?php echo e(route('edit-operator',$row->id)); ?>"
                                            class="btn btn-success btn-sm">
                                            <i class="fa fa-edit text-dark"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <br>
                    <div class="d-flex justify-content-center">
                        <?php echo e($user->links()); ?>


                    </div>
                </div>
            </div>
        </div>
        <div class="content-backdrop fade"></div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function() {
                window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerDelete', id => {
                    Swal.fire({
                        title: 'Hapus data ini?',
                        text: "Data yang sudah dihapus tidak dapat kembali!",
                        icon: 'warning',
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        showCancelButton: true,
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.livewire.find('<?php echo e($_instance->id); ?>').call('delete', id)
                        }
                    });
                });
            })
        </script>
    <?php $__env->stopPush(); ?>

    <?php if(session()->has('hapus')): ?>
        <script>
            Swal.fire(
                "Informasi",
                "<?php echo e(session('hapus')); ?>",
                "success"
            );
        </script>
    <?php endif; ?>

</div>
<?php /**PATH C:\laravel\sortir_barang\resources\views/livewire/backend/user/user.blade.php ENDPATH**/ ?>