<div>
    <div class="content-wrapper">
        <!-- Content -->

        <div class="container-xxl flex-grow-1 container-p-y">
            <div class="card">
                <div class="card-header">
                    Data Produk PerOutlet </div>
                <div class="card-body table-responsive">
                    <table class="table  table-hover table-bordered" id="">
                        <thead class="student-thread">
                            <tr>
                                <th>No</th>
                                <th>Produk</th>
                                <th>Terjual</th>
                                <th>Harga</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $no = 0; ?>
                            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $no++; ?>
                                <tr>
                                    <td>
                                        <?php echo $no; ?>
                                    </td>
                                    <td><?php echo e($row->product); ?></td>
                                    <td><?php echo e($row->terjual); ?></td>
                                    <td><?php echo e(number_format($row->price, 0, ',', '.')); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('edit-product', $row->id)); ?>" class="btn btn-success btn-sm">
                                            <i class="fa fa-edit text-dark"></i>
                                        </a>
                                        <a wire:click="$emit('triggerDelete',<?php echo e($row->id); ?>)"
                                            class="btn btn-danger btn-sm">
                                            <i class="fa fa-trash text-light"></i>
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <br>
                    <div class="alert alert-info" role="alert">
                        <strong>Total Penjualan : </strong> <?php echo e(number_format($product->sum('price'), 0, ',', '.')); ?>

                    </div>
                    <div class="d-flex justify-content-center">
                        

                    </div>
                </div>
            </div>
        </div>
        <div class="content-backdrop fade"></div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function() {
                window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerDelete', id => {
                    Swal.fire({
                        title: 'Hapus data ini?',
                        text: "Data yang sudah dihapus tidak dapat kembali!",
                        icon: 'warning',
                        confirmButtonColor: '#3085d6',
                        cancelButtonColor: '#d33',
                        showCancelButton: true,
                    }).then((result) => {
                        if (result.isConfirmed) {
                            window.livewire.find('<?php echo e($_instance->id); ?>').call('delete', id)
                        }
                    });
                });
            })
        </script>
    <?php $__env->stopPush(); ?>

    <?php if(session()->has('hapus')): ?>
        <script>
            Swal.fire(
                "Informasi",
                "<?php echo e(session('hapus')); ?>",
                "success"
            );
        </script>
    <?php endif; ?>

</div>
<?php /**PATH C:\laravel\sortir_barang\resources\views/livewire/backend/product/detailproduct.blade.php ENDPATH**/ ?>